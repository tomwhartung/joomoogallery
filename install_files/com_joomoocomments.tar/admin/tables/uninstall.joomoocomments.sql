#
# version     $Id: uninstall.joomoocomments.sql,v 1.2 2008/11/03 21:40:41 tomh Exp tomh $
# author      Tom Hartung <webmaster@tomhartung.com>
# database    MySql
# copyright   Copyright (C) 2008 Tom Hartung. All rights reserved.
# license     TBD
#
# 
# SQL to delete jos_joomoocomments table
#
DROP TABLE IF EXISTS `jos_joomoocomments`;

